package com.rabo.customer.statement.processor.constants;

import java.io.File;
import java.util.List;

import com.rabo.customer.statement.processor.vo.CustomerStatement;

public class CustomerStatementProcessorConstants {

	public static String[] csvHeaders = new String[] { "transactionReference", "accountNumber", "description",
												"startingBalance", "mutation", "endingBalance" };
	public static String exceptionMessage = "Error Reading File.Please check the file and try again.";
	public static String logExceptionMessage = "Exception caught. Exception Message : ";
	public static String enter = "Entering ";
	public static String exit = "Exiting ";
	public static String fileEmptyOrNotFound = "File is empty or not selected.Please try again.";
	public static String fileFormatException = "Incorrect File format.Upload csv or xml file";

}
