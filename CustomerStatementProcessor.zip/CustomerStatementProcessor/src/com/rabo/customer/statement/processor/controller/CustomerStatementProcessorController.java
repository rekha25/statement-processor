package com.rabo.customer.statement.processor.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.rabo.customer.statement.processor.constants.CustomerStatementProcessorConstants;
import com.rabo.customer.statement.processor.delegate.CustomerStatementProcessorBusinessDelegate;
import com.rabo.customer.statement.processor.exception.CustomerStatementProcessorException;

@Controller
public class CustomerStatementProcessorController {

	@Autowired
	CustomerStatementProcessorBusinessDelegate statementDelegate;

	@RequestMapping(value = "/editUpload")
	public String viewEditUpload() {
		return "fileUpload";
	}

	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
	public String uploadFileHandler(@RequestParam("file") MultipartFile file, ModelMap model) {

		if (!file.isEmpty()) {

			model.put("failedRecords", statementDelegate.readIncomingFile(file));

		} else {
			throw new CustomerStatementProcessorException(CustomerStatementProcessorConstants.fileEmptyOrNotFound);
		}

		return "output";

	}

}
