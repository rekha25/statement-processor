package com.rabo.customer.statement.processor.delegate;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.rabo.customer.statement.processor.vo.CustomerStatement;

public interface CustomerStatementProcessorBusinessDelegate {

	public List<CustomerStatement> readIncomingFile(MultipartFile file);

}
