package com.rabo.customer.statement.processor.delegate.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import com.rabo.customer.statement.processor.constants.CustomerStatementProcessorConstants;
import com.rabo.customer.statement.processor.delegate.CustomerStatementProcessorBusinessDelegate;
import com.rabo.customer.statement.processor.exception.CustomerStatementProcessorException;
import com.rabo.customer.statement.processor.service.CustomerStatementProcessorService;
import com.rabo.customer.statement.processor.vo.CustomerStatement;

public class CustomerStatementProcessorBusinessDelegateImpl implements CustomerStatementProcessorBusinessDelegate {

	@Autowired
	CustomerStatementProcessorService statementService;

	@Override
	public List<CustomerStatement> readIncomingFile(MultipartFile file) {

		if (file.getOriginalFilename().contains(".csv")) { 					// reads csv files
			return statementService.readCSVFile(file);
		} else if (file.getOriginalFilename().contains(".xml")) { 		   // reads xml files
			return statementService.readXMLFile(file);
		} else {
			throw new CustomerStatementProcessorException(CustomerStatementProcessorConstants.fileFormatException);
		}
	}
}
