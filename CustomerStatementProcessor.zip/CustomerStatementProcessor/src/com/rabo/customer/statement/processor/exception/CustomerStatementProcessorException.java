package com.rabo.customer.statement.processor.exception;

public class CustomerStatementProcessorException extends RuntimeException {

	private String message;

	public CustomerStatementProcessorException(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
