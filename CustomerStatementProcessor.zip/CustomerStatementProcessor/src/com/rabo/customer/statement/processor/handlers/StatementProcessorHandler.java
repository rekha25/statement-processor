package com.rabo.customer.statement.processor.handlers;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.rabo.customer.statement.processor.exception.CustomerStatementProcessorException;
import com.rabo.customer.statement.processor.vo.CustomerStatement;

public class StatementProcessorHandler extends DefaultHandler {

	private List<CustomerStatement> statementRecords = null; 		// Holds List of records
	private CustomerStatement custStatment = null; 				   // Holds single record

	boolean reference = false;
	boolean accountNumber = false;
	boolean description = false;
	boolean startingBalance = false;
	boolean mutation = false;
	boolean endingBalance = false;

	public static StatementProcessorHandler getInstance() {
		return new StatementProcessorHandler();
	}

	public List<CustomerStatement> getStatementRecords() {
		return statementRecords;
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("record")) {
			String tranReference = attributes.getValue("reference");
			custStatment = new CustomerStatement();
			custStatment.setTransactionReference(tranReference);
			if (statementRecords == null)
				statementRecords = new ArrayList<CustomerStatement>();
		} else if (qName.equalsIgnoreCase("accountNumber")) {
			accountNumber = true;
		} else if (qName.equalsIgnoreCase("description")) {
			description = true;
		} else if (qName.equalsIgnoreCase("startBalance")) {
			startingBalance = true;
		} else if (qName.equalsIgnoreCase("mutation")) {
			mutation = true;
		} else if (qName.equalsIgnoreCase("endBalance")) {
			endingBalance = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (qName.equalsIgnoreCase("record")) {
			statementRecords.add(custStatment);
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (accountNumber) {
			custStatment.setAccountNumber(new String(ch, start, length));
			accountNumber = false;
		} else if (description) {
			custStatment.setDescription(new String(ch, start, length));
			description = false;
		} else if (startingBalance) {
			custStatment.setStartingBalance(new String(ch, start, length));
			startingBalance = false;
		} else if (mutation) {
			custStatment.setMutation(new String(ch, start, length));
			mutation = false;
		} else if (endingBalance) {
			custStatment.setEndingBalance(new String(ch, start, length));
			endingBalance = false;
		}
	}

}
