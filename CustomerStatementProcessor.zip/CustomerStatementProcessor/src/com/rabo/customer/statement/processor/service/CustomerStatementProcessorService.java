package com.rabo.customer.statement.processor.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.rabo.customer.statement.processor.vo.CustomerStatement;

public interface CustomerStatementProcessorService {

	public List<CustomerStatement> readCSVFile(MultipartFile input);

	public List<CustomerStatement> readXMLFile(MultipartFile input);
}
