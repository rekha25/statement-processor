package com.rabo.customer.statement.processor.service.impl;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.multipart.MultipartFile;
import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.prefs.CsvPreference;
import org.xml.sax.SAXException;

import com.rabo.customer.statement.processor.constants.CustomerStatementProcessorConstants;
import com.rabo.customer.statement.processor.exception.CustomerStatementProcessorException;
import com.rabo.customer.statement.processor.handlers.StatementProcessorHandler;
import com.rabo.customer.statement.processor.service.CustomerStatementProcessorService;
import com.rabo.customer.statement.processor.vo.CustomerStatement;

public class CustomerStatementProcessorServiceImpl implements CustomerStatementProcessorService {

	private static final Log logger = LogFactory.getLog(CustomerStatementProcessorServiceImpl.class.getName());

	private static CellProcessor[] getProcessors() {

		final CellProcessor[] processors = new CellProcessor[] { new Optional(), new Optional(), new Optional(),
													new Optional(), new Optional(), new Optional() };

		return processors;
	}

	private boolean hasValue(String value) {
		if (value != null && !value.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public List<CustomerStatement> readCSVFile(MultipartFile input) {

		logger.info(CustomerStatementProcessorConstants.enter + CustomerStatementProcessorServiceImpl.class.getName()
				+ " readCsvFile()");
		ICsvBeanReader beanReader = null;
		final String[] header = CustomerStatementProcessorConstants.csvHeaders;
		CustomerStatement customerStatement;
		boolean skipHeader = true;
		List<CustomerStatement> failedRecords = new ArrayList<CustomerStatement>();
		Set<String> uniqueReference = new HashSet<String>();
		Map<String, CustomerStatement> uniqueRecords = new HashMap<String, CustomerStatement>();

		try {
			beanReader = new CsvBeanReader(new InputStreamReader(input.getInputStream()),CsvPreference.STANDARD_PREFERENCE);
			final CellProcessor[] processors = getProcessors();
			while ((customerStatement = beanReader.read(CustomerStatement.class, header, processors)) != null) {

				if (skipHeader) {
					skipHeader = false;
					continue;
				}
				validateRecord(customerStatement, failedRecords, uniqueReference, uniqueRecords);

			}
		} catch (IOException e) {
			logger.info(CustomerStatementProcessorConstants.logExceptionMessage + e.getMessage());
			throw new CustomerStatementProcessorException(CustomerStatementProcessorConstants.exceptionMessage);
		} finally {
			if (beanReader != null) {
				try {
					beanReader.close();
				} catch (IOException e) {
					logger.info(CustomerStatementProcessorConstants.logExceptionMessage + e.getMessage());
					throw new CustomerStatementProcessorException(CustomerStatementProcessorConstants.exceptionMessage);
				}
			}
		}
		logger.info(CustomerStatementProcessorConstants.exit + CustomerStatementProcessorServiceImpl.class.getName()
				+ " readCsvFile()");
		return failedRecords;
	}

	@Override
	public List<CustomerStatement> readXMLFile(MultipartFile input) {

		logger.info(CustomerStatementProcessorConstants.enter + CustomerStatementProcessorServiceImpl.class.getName()
				+ " readXMLFile()");
		SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
		List<CustomerStatement> failedRecords = new ArrayList<CustomerStatement>();
		Set<String> uniqueReference = new HashSet<String>();
		Map<String, CustomerStatement> uniqueRecords = new HashMap<String, CustomerStatement>();
		try {
			SAXParser saxParser = saxParserFactory.newSAXParser();
			StatementProcessorHandler statementHandler = StatementProcessorHandler.getInstance();
			saxParser.parse(input.getInputStream(), statementHandler);
			List<CustomerStatement> statementRecords = statementHandler.getStatementRecords();
			for (CustomerStatement statement : statementRecords) {
				validateRecord(statement, failedRecords, uniqueReference, uniqueRecords);
			}

		} catch (ParserConfigurationException | SAXException | IOException e) {
			logger.info(CustomerStatementProcessorConstants.logExceptionMessage + e.getMessage());
			throw new CustomerStatementProcessorException(CustomerStatementProcessorConstants.exceptionMessage);
		}
		logger.info(CustomerStatementProcessorConstants.exit + CustomerStatementProcessorServiceImpl.class.getName()
				+ " readXMLFile()");
		return failedRecords;
	}

	private void validateRecord(CustomerStatement customerStatement, List<CustomerStatement> failedRecords,
			Set<String> uniqueReference, Map<String, CustomerStatement> uniqueRecords) {

		logger.info(CustomerStatementProcessorConstants.enter + CustomerStatementProcessorServiceImpl.class.getName()
				+ " validateRecord()");

		if (hasValue(customerStatement.getTransactionReference()) && customerStatement.getTransactionReference()
				.matches("[0-9]{" + customerStatement.getTransactionReference().length() + "}")) {

			if (!uniqueReference.add(customerStatement.getTransactionReference())) {
				failedRecords.add(customerStatement);
				if (uniqueRecords.containsKey(customerStatement.getTransactionReference())) {
					failedRecords.add(uniqueRecords.get(customerStatement.getTransactionReference()));
					uniqueRecords.remove(customerStatement.getTransactionReference());
				}
			} else {
				uniqueRecords.put(customerStatement.getTransactionReference(), customerStatement);
			}
		} else {
			failedRecords.add(customerStatement);
		}
		if (!hasValue(customerStatement.getEndingBalance())
				|| !customerStatement.getEndingBalance().matches("-?[0-9]{1,13}(\\.[0-9]*)?")
						&& !failedRecords.contains(customerStatement)) {
			failedRecords.add(customerStatement);
		}

		logger.info(CustomerStatementProcessorConstants.exit + CustomerStatementProcessorServiceImpl.class.getName()
				+ " validateRecord()");

	}

}
