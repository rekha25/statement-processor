package com.rabo.customer.statement.processor.vo;

public class CustomerStatement {

	private String transactionReference;
	private String accountNumber;
	private String startingBalance;
	private String description;
	private String mutation;
	private String endingBalance;

	public String getTransactionReference() {
		return transactionReference;
	}

	public void setTransactionReference(String transactionReference) {
		this.transactionReference = transactionReference;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getStartingBalance() {
		return startingBalance;
	}

	public void setStartingBalance(String startingBalance) {
		this.startingBalance = startingBalance;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMutation() {
		return mutation;
	}

	public void setMutation(String mutation) {
		this.mutation = mutation;
	}

	public String getEndingBalance() {
		return endingBalance;
	}

	public void setEndingBalance(String endingBalance) {
		this.endingBalance = endingBalance;
	}

}
