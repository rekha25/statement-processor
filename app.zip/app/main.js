var mainApp = angular.module("mainApp", ['ngRoute']);

mainApp.config(function($routeProvider) {

	$routeProvider
		.when('/home', {
			templateUrl: 'home.html',
			controller: 'StatementProcessorController'
		})
		.when('/viewStatements', {
			templateUrl: 'viewInvalidRecords.html',
			controller: 'ViewInvalidRecordsController'
		}).when('/editUpload', {
			templateUrl: 'fileUpload.html',
			controller: 'StatementProcessorController'
		})
		.otherwise({
			redirectTo: '/home'
		});

});

mainApp.directive('ngFileSelect',  function ($parse) {
            return {
               restrict: 'A',
               link: function(scope, element, attrs) {
                  var model = $parse(attrs.fileModel);
                  var modelSetter = model.assign;
                  
                  element.bind('change', function(e){
                  	 scope.file =  e.target.files[0];
                  	 scope.contents = "";
                  });

                  
               }
            };
         });

mainApp.controller('StatementProcessorController', ['$scope','$http','$location','StatementProcessorService',function($scope,$http,$location,StatementProcessorService) {

	$scope.readAndValidateFile = function(){
	 	var file = $scope.file;
	 	    if(file.name.indexOf(".xml") !== -1){

               	var x2js = new X2JS();
                var fileContents = x2js.xml_str2json($scope.contents);
                $scope.validateRecords(fileContents.records.record);

            }else if(file.name.indexOf(".csv") !== -1){
                
                var rows = $scope.contents.split(/\r\n|\n/);
    			var headers = rows[0].split(',');
    			var lines = [];
    			var result = {};

    		for (var i=1; i<rows.length; i++) {

        		var data = rows[i].split(',');

        			if (data.length == headers.length) {

            			var j = 0;
                		var result = {};
                		result._reference = data[j];
		                result.accountNumber = data[++j];
		                result.description = data[++j];
		                result.startBalance = data[++j];
		                result.mutation = data[++j];
		                result.endBalance = data[++j];
		                lines.push(result);

            		}
            	
        	}
        		$scope.validateRecords(lines);

            } else {
               	
               	alert("Upload either csv or xml file");
            
            }

            StatementProcessorService.setResult($scope.duplicate);

          $location.path('/viewStatements');

	};
	 
	$scope.validateRecords = function(statements){

	 		$scope.duplicate    =    statements.filter((set => f => set.has(f._reference) || !set.add(f._reference))(new Set));
            var unique          =    statements.filter((set => f => !set.has(f._reference) && set.add(f._reference))(new Set));
            var uniqueFilter    =    $scope.duplicate.filter((set => f => !set.has(f._reference) && set.add(f._reference))(new Set));


            var doubleRegex = /^[+-]?([0-9]*[.])?[0-9]+$/;

            for(var i=0;i<unique.length;i++){
                if(!doubleRegex.test(unique[i].endBalance) && $scope.duplicate.indexOf(unique[i]) == -1){
                    $scope.duplicate.push(unique[i]);
                }

                for(var j=0;j<uniqueFilter.length;j++){
                	if(uniqueFilter[j]._reference === unique[i]._reference){
                		$scope.duplicate.push(unique[i]);
                		uniqueFilter.splice(j,1);
                		break;
                	}
                }
            }

	};

	$scope.uploadFile = function(){
				
			var reader = new FileReader();
            reader.onload = function (e){
               	$scope.contents = e.target.result;
               	$scope.readAndValidateFile();
            };
            var fileContent = reader.readAsText($scope.file);
    };

}]);

mainApp.controller('ViewInvalidRecordsController',['$scope','StatementProcessorService',function($scope,StatementProcessorService){

		$scope.invalidRecords = StatementProcessorService.getResult();
}]);

mainApp.service('StatementProcessorService',function($http){

		this.result = {};
		this.setResult = function (result) {
        this.result = result;
    		};
    	this.getResult = function (){
    		return this.result;
    	};
     	
});

